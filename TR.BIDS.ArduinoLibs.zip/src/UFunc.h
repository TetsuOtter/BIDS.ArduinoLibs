//UFunc.h
//Under the CC0 License
//written by Tetsu Otter

#ifndef U_FUNC
#define U_FUNC

void LD2CA(char* ca, int startIndex, int len, int dnlen, double ld);
void ZeroFill(char* c,int l);

#endif
